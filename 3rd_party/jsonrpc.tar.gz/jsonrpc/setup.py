#!/usr/bin/env python

from distutils.core import setup

setup(name = "jsonrpc",
    version = "0.1beta",
    description = "A json-rpc package which implements JSON-RPC.",
    keywords = "JSON RPC",
    author = "Jan-Klaas Kollhof",
    url = "http://json-rpc.org/wiki/python-json-rpc",
    license = "LGPL",
    long_description = """
This module provides functionality for making JSON-RPC services available through CGI.
In addition it provides a mod_python handler for providing services through mod_python which is more perfomant than CGI.
There is also some "JSON-RPC over sockets" implementation.
""",
    packages = ['jsonrpc']
)